# Simulacros ICFES IA
Frontend y backend Node.js + Express.
Para Render: Build Command `npm install`; Start Command `npm start`.
Incluye API para guardar y consultar resultados. No procesa pagos reales.
