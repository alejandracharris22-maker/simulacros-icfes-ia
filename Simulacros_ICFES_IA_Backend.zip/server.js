const express=require("express");
const sqlite3=require("sqlite3").verbose();
const path=require("path");
const app=express();
const PORT=process.env.PORT||3000;
const db=new sqlite3.Database(process.env.DB_PATH||"./icfes.db");

app.use(express.json());
app.use(express.static(path.join(__dirname,"public")));

db.serialize(()=>db.run(`CREATE TABLE IF NOT EXISTS attempts(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 area TEXT NOT NULL,
 score INTEGER NOT NULL,
 total INTEGER NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
)`));

app.get("/api/health",(req,res)=>res.json({ok:true,service:"Simulacros ICFES IA API"}));

app.post("/api/attempts",(req,res)=>{
 const {area,score,total}=req.body;
 if(typeof area!=="string"||!Number.isInteger(score)||!Number.isInteger(total)||total<=0||score<0||score>total)
   return res.status(400).json({error:"Datos inválidos"});
 db.run("INSERT INTO attempts(area,score,total) VALUES(?,?,?)",[area,score,total],function(err){
   if(err)return res.status(500).json({error:"No se pudo guardar"});
   res.status(201).json({id:this.lastID,area,score,total,percentage:Math.round(score/total*100)});
 });
});

app.get("/api/results",(req,res)=>{
 db.all("SELECT * FROM attempts ORDER BY id DESC LIMIT 100",[],(err,rows)=>{
   if(err)return res.status(500).json({error:"No se pudieron consultar"});
   res.json(rows);
 });
});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log("http://localhost:"+PORT));
